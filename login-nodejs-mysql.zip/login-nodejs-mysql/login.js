const mysql = require("mysql");
const express = require("express");
const encoder = bodyParser.urlencoded();

const app = express();
app.use("/assets",express.static("assets"));

const connection = mysql.createConnection({
    host: "localhost",
    user: "root",
    password: "",
    database: "nodejs"
});

// connect to the database
connection.connect(function(error){
    if (error) throw error
    else console.log("connected to the database successfully!")
});


app.get("/",function(req,res){
    res.sendFile(__dirname + "/index.html");
})

app.post("/",encoder, function(req,res){
    var username = req.body.username;
    var password = req.body.password;

    connection.query("select * from loginadmin where admin_name = ? and admin_pass = ?",[username,password],function(error,results,fields){
        if (results.length > 0) {
            res.redirect("/Member details");
        } else {
            res.redirect("/");
        }
        res.end();
    })
})

// when login is success
app.get("/member",function(req,res){
    res.sendFile(__dirname + "/member.html")
})


// set app port 
app.listen(4000);